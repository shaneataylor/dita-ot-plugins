(function () { ditasearch.init(); })();
